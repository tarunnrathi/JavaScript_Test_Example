const COMMON_CONFIG = {
    THUMBNAIL_IMAGE_PLACEHOLDER_PATH: "https://images.news18.com/ibnkhabar/uploads/assests/images/placeholder.jpg",
};
module.exports = COMMON_CONFIG;