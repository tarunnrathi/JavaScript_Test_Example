import { createContext } from "react";

const HindiGlobalContext = createContext();

export default HindiGlobalContext;
