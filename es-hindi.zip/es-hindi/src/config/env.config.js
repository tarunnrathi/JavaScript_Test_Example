const ENV_CONfIG = {
    LANG_CODE: "hi",
    siteAd: "true",
};

module.exports = ENV_CONfIG;
