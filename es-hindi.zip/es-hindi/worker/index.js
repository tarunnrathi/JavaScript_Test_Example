var izCacheVer = 1;
importScripts(
  'https://cdn.izooto.com/scripts/workers/bbb67b29306b45dfa1a7ccd866c1f6a55f8dc9dd.js'
);