import React from "react";

const healthcheck = () => {
  return (
    <p>Working Fine.</p>
  );
};

export default healthcheck;
