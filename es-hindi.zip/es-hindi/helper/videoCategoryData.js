const video_category = [
    {
      slug: "originals/",
      key: "originals",
      title: "Originals",
    },
    {
      slug: "local18/",
      key: "local18",
      title: "लोकल18",
    },
    {
      slug: "entertainment/",
      key: "entertainment",
      title: "मनोरंजन",
    },
    {
      slug: "cricket/",
      key: "cricket",
      title: "क्रिकेट",
    },
    {
      slug: "lifestyle/",
      key: "lifestyle",
      title: "लाइफस्टाइल",
    },
    {
      slug: "tech/",
      key: "tech",
      title: "टेक",
    },
    {
      slug: "nation/",
      key: "nation",
      title: "देश",
    },
    {
      slug: "sports/",
      key: "sports",
      title: "स्पोर्ट्स",
    },
    {
      slug: "short-videos/",
      key: "short-videos",
      title: "शोर्ट्स",
    },
  ];

  export default video_category 